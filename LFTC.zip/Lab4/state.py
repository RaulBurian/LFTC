class State:
    NORMAL = 'q'
    ERROR = 'e'
    BACK = 'b'
    FINAL = 'f'
